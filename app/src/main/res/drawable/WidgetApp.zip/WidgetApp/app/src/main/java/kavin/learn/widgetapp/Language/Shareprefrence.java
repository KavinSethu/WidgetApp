package kavin.learn.widgetapp.Language;

/**
 * Created by Kavin on 12/18/2019.
 */
public class Shareprefrence {

    public static final String KEY_LANG = "location";


}
