package kavin.learn.widgetapp.Assignment;

public class AssignBottomPojo {

    String name,image;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
